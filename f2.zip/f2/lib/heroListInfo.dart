import 'dart:ffi';

import 'package:flutter/material.dart';
import 'Personjx.dart';
import 'package:flutter/services.dart';
// json
import 'dart:convert';
// 异步 Future
import 'dart:async';
import 'tyinTypeClass.dart';
import 'HeroListClass.dart';


class dynamicHeroClass extends StatefulWidget{

  heroListInfo createState()=>heroListInfo();
}

class heroListInfo extends State<dynamicHeroClass>{


  Widget build(BuildContext context){
    return Scaffold(
      body: Container(
        child: Column(
          children: <Widget>[
            tyinTypeClass(),//调用分栏类
          ],
        ),
      ),
    );
  }
}
