import 'package:flutter/material.dart';
import 'videoPlayerxClass.dart';

import 'package:flutter/material.dart';
import 'videoPlayerxClass.dart';

class VideoPlayClass extends StatelessWidget{

  @override

  Widget build(BuildContext context){
    return Container(
        height: 700,
        //color: Color.fromARGB(250, 34, 28, 51),
        child: ListView(
          physics: new NeverScrollableScrollPhysics(),//禁用滚动事件
          children: <Widget>[
            Container(
              height: 15,
            ),
            Container(
              alignment: Alignment.center,
              child: Text('专业的英雄视频，解说视频',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
            ),
            Container(
              height: 15,
            ),
            Container(
                height: 700,
                color: Color.fromARGB(250, 34, 28, 51),
                child:  Container(
                  child: GridView.count(
                    crossAxisSpacing: 10.0,
                    crossAxisCount: 2,
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          Container(

                            height: 150,
                            color: Colors.white,
                            child: Center(
                                child:
                                GestureDetector(
                                  onTap: (){

//                              print(heroList[index]['name']);
////                                  MaterialPageRoute(
////                                    builder: (context)=>HeroIntroduction()
////                                  );
                                    Navigator.push(context, MaterialPageRoute(//切换页面
                                        builder:(context)=>ChewieVideoDemo(spPlayerIdx:0)
                                    ));
                                  },
                                  child: Stack(
                                    children: <Widget>[
                                      Image.network(
                                        'https://puui.qpic.cn/qqvideo_ori/0/o3026viwwlc_1280_720/0',
                                        fit: BoxFit.cover,
                                        width: 250,
                                        height: 150,
                                      ),
                                      Positioned(
                                          left: 82.0,
                                          bottom: 45.0,
                                          child: Image.asset('imagesn/10.png',
                                          )
                                      )
                                    ],

                                  ),
                                )
                            ),
                            //color:Colors.black87
                          ),
                          Positioned(
                              left: 55.0,
                              bottom: 15.0,
                              child: Text('蹭梦泪的毛',
                                  style: TextStyle(
                                      fontSize: 20.0, color: Colors.purpleAccent))
                          ),

                        ],
                      ),
                      Stack(
                        children: <Widget>[
                          Container(

                            height: 150,
                            color: Colors.white,
                            child: Center(
                                child:
                                GestureDetector(
                                  onTap: (){
//                              print(heroList[index]['name']);
////                                  MaterialPageRoute(
////                                    builder: (context)=>HeroIntroduction()
////                                  );
                                    Navigator.push(context, MaterialPageRoute(//切换页面
                                        builder:(context)=>ChewieVideoDemo(spPlayerIdx:1)
                                    ));
                                  },
                                  child: Stack(
                                    children: <Widget>[
                                      Image.network(
                                        'https://puui.qpic.cn/qqvideo_ori/0/p0904oeyu12_1280_720/0',
                                        fit: BoxFit.cover,
                                        width: 250,
                                        height: 150,
                                      ),
                                      Positioned(
                                          left: 82.0,
                                          bottom: 45.0,
                                          child: Image.asset('imagesn/10.png',
                                          )
                                      )
                                    ],

                                  ),
                                )
                            ),
                            //color:Colors.black87
                          ),
                          Positioned(
                              left: 35.0,
                              bottom: 15.0,
                              child: Text('职业玩家都玩的',
                                  style: TextStyle(
                                      fontSize: 20.0, color: Colors.purpleAccent))
                          ),

                        ],
                      ),
                      Stack(
                        children: <Widget>[
                          Container(

                            height: 150,
                            color: Colors.white,
                            child: Center(
                                child:
                                GestureDetector(
                                  onTap: (){
//                              print(heroList[index]['name']);
////                                  MaterialPageRoute(
////                                    builder: (context)=>HeroIntroduction()
////                                  );
                                    Navigator.push(context, MaterialPageRoute(//切换页面
                                        builder:(context)=>ChewieVideoDemo(spPlayerIdx:2)
                                    ));
                                  },

                                  child: Stack(
                                    children: <Widget>[
                                      Image.network(
                                        'https://shp.qpic.cn/cfwebcap/1546387229/188069b1214e89b24cef192500b4a621/0/?width=230&height=140',
                                        fit: BoxFit.cover,
                                        width: 250,
                                        height: 150,
                                      ),
                                      Positioned(
                                          left: 82.0,
                                          bottom: 45.0,
                                          child: Image.asset('imagesn/10.png',
                                          )
                                      )
                                    ],

                                  ),

                                )
                            ),
                            //color:Colors.black87
                          ),
                          Positioned(
                              left: 45.0,
                              bottom: 15.0,
                              child: Text('最强单挑王铠',
                                  style: TextStyle(
                                      fontSize: 20.0, color: Colors.purpleAccent))
                          ),

                        ],
                      ),
                      Stack(
                        children: <Widget>[
                          Container(

                            height: 150,
                            color: Colors.white,
                            child: Center(
                                child:
                                GestureDetector(
                                  onTap: (){
//                              print(heroList[index]['name']);
////                                  MaterialPageRoute(
////                                    builder: (context)=>HeroIntroduction()
////                                  );
                                    Navigator.push(context, MaterialPageRoute(//切换页面
                                        builder:(context)=>ChewieVideoDemo(spPlayerIdx:3)
                                    ));
                                  },

                                  child: Stack(
                                    children: <Widget>[
                                      Image.network(
                                        'https://shp.qpic.cn/qqvideo_ori/0/x0331cgavc3_228_128/0',
                                        fit: BoxFit.cover,
                                        width: 250,
                                        height: 150,
                                      ),
                                      Positioned(
                                          left: 82.0,
                                          bottom: 45.0,
                                          child: Image.asset('imagesn/10.png',
                                          )
                                      )
                                    ],

                                  ),

                                )
                            ),
                            //color:Colors.black87
                          ),
                          Positioned(
                              left: 35.0,
                              bottom: 15.0,
                              child: Text('荣耀时刻TOP5',
                                  style: TextStyle(
                                      fontSize: 20.0, color: Colors.purpleAccent))
                          ),

                        ],
                      ),
                      Stack(
                        children: <Widget>[
                          Container(

                            height: 150,
                            color: Colors.white,
                            child: Center(
                                child:
                                GestureDetector(
                                  onTap: (){
//                              print(heroList[index]['name']);
////                                  MaterialPageRoute(
////                                    builder: (context)=>HeroIntroduction()
////                                  );
                                    Navigator.push(context, MaterialPageRoute(//切换页面
                                        builder:(context)=>ChewieVideoDemo(spPlayerIdx:4)
                                    ));
                                  },

                                  child: Stack(
                                    children: <Widget>[
                                      Image.network(
                                        'https://itea-cdn.qq.com/file/tgl/20190830/c81e728d9d4c2f636f067f89cc14862c.1567152900.fa9841f527378e14c7ba18907d6982b3.230x140_62486.png',
                                        fit: BoxFit.cover,
                                        width: 250,
                                        height: 150,
                                      ),
                                      Positioned(
                                          left: 82.0,
                                          bottom: 45.0,
                                          child: Image.asset('imagesn/10.png',
                                          )
                                      )
                                    ],

                                  ),

                                )
                            ),
                            //color:Colors.black87
                          ),
                          Positioned(
                              left: 17.0,
                              bottom: 15.0,
                              child: Text('残血马超，完成双杀',
                                  style: TextStyle(
                                      fontSize: 20.0, color: Colors.purpleAccent))
                          ),

                        ],
                      ),
                      Stack(
                        children: <Widget>[
                          Container(

                            height: 150,
                            color: Colors.white,
                            child: Center(
                                child:
                                GestureDetector(
                                  onTap: (){
//                              print(heroList[index]['name']);
////                                  MaterialPageRoute(
////                                    builder: (context)=>HeroIntroduction()
////                                  );
                                    Navigator.push(context, MaterialPageRoute(//切换页面
                                        builder:(context)=>ChewieVideoDemo(spPlayerIdx:5)
                                    ));
                                  },

                                  child: Stack(
                                    children: <Widget>[
                                      Image.network(
                                        'https://puui.qpic.cn/qqvideo_ori/0/z092122i7uv_1280_720/0',
                                        fit: BoxFit.cover,
                                        width: 250,
                                        height: 150,
                                      ),
                                      Positioned(
                                          left: 82.0,
                                          bottom: 45.0,
                                          child: Image.asset('imagesn/10.png',
                                          )
                                      )
                                    ],

                                  ),

                                )
                            ),
                            //color:Colors.black87
                          ),
                          Positioned(
                              left: 25.0,
                              bottom: 15.0,
                              child: Text('花满楼世冠马可波',
                                  style: TextStyle(
                                      fontSize: 20.0, color: Colors.purpleAccent))
                          ),

                        ],
                      ),
                    ],
                  ),
                  //color: Colors.black,
                )
            )

          ],
        )
    );
  }
}