import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:ui';
import 'personalNews.dart';
import 'main.dart';
import 'dart:convert';
import 'dart:async';
import 'package:fluttertoast/fluttertoast.dart';

class PaginationType4 extends StatefulWidget {
  _PaginationType4 createState() => _PaginationType4();
}

class _PaginationType4 extends State<PaginationType4>{

  @override
  factory _PaginationType4() =>_getInstance();
  static _PaginationType4 _instance;
  static _PaginationType4 _getInstance() {
    _instance = new _PaginationType4._internal();
    return _instance;
  }
  void UpdateState(){
    setState(() {

    });


  }
  _PaginationType4._internal() {
    // 初始化
  }
  Widget build(BuildContext context){
    //_Persinformation().initFromCache();
    Widget PaginatLogin;
    if(MyApp.ascendproces==false)
      {
        return Scaffold(
            appBar: PreferredSize(
                child: AppBar(
                  title: Text('登陆'),
                  brightness: Brightness.light,
                  backgroundColor: Colors.deepPurpleAccent,
                ),
                preferredSize: Size.fromHeight(45)),
            body: Center(
              child: Stack(
                children: <Widget>[
                  Image.asset('imagesn/13.jpg',
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    fit: BoxFit.cover,

                  ),
                  LoginPage(),
                ],
              ),
            )
        );

      }
    else{
      PaginatLogin=Scaffold(
          body: Center(
            child: Column(
              children: <Widget>[

                personalHoad(),
                Persinformation(),

              ],
            ),
          )
      );
    }

    return PaginatLogin;

  }
}


class BottomClipper extends CustomClipper<Path>{
  @override
  Path getClip(Size size) {
    // TODO: implement getClip
    var path = Path();
    path.lineTo(0, size.height);
    var firstControlPoint =Offset(size.width/4,size.height);
    var firstEndPoint = Offset(size.width/2.25,size.height);

//   // path.quadraticBezierTo(firstControlPoint.dx, firstControlPoint.dy, firstEndPoint.dx, firstEndPoint.dy);
//
//    var secondControlPoint = Offset(size.width/4*3,size.height-80);
//    var secondEndPoint = Offset(size.width,size.height-40);
//
//    path.quadraticBezierTo(secondControlPoint.dx, secondControlPoint.dy, secondEndPoint.dx, secondEndPoint.dy);
//
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);

    return path;

  }
  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    // TODO: implement shouldReclip
    return false;
  }

}


//头像类
class personalHoad extends StatelessWidget{

  @override

  Widget build(BuildContext context){

    return Container(
        child:  Stack(
          children: <Widget>[
            ClipPath(
                clipper:BottomClipper(),
                child: Container(
                  color:Colors.deepPurpleAccent,
                  alignment: Alignment.center,
                  height: 200.0,
                  width: double.infinity,
                  child: Stack(
                    children: <Widget>[
                      Image.asset('imagesn/1.png',
                        width: 80,
                        height: 80,
                      ),


                    ],
                  )
                  ,
                )),


              Container(
                  width: MediaQuery.of(context).size.width,
                  height: 100,
                  alignment: Alignment.lerp(Alignment.center, Alignment.bottomCenter, 3),
                  child:   Text(MyApp.paginationname,
                      style: TextStyle(
                          fontSize: 20.0,color: Colors.white,fontWeight: FontWeight.w700))
              ),
          ],
        ),
    );

  }
}

class Persinformation extends StatefulWidget{
  _Persinformation createState()=> _Persinformation();


}

//个人信息
class _Persinformation extends State<Persinformation>{

  @override
  Widget build(BuildContext context){
    return Container(
      width: MediaQuery.of(context).size.width,
      height: window.physicalSize.height/3.3,
           color: Color.fromRGBO(255, 180, 150, 230),

            child:MediaQuery.removePadding(
                removeTop: true,
                context: context,
                child: ListView(
                  scrollDirection: Axis.vertical,
                  physics: NeverScrollableScrollPhysics(),
                  children: <Widget>[
                    Stack(
                      children: <Widget>[
                        Container(
                          width: window.physicalSize.width,
                          height: 70,
                          color: Colors.white,
                        ),
                        Positioned(
                          top: 30,
                          left: 23,
                          child: Text('视频',style: TextStyle(fontSize: 19,color: Colors.black87),),
                        ),
                        Positioned(
                          top: 10,
                          left: 38,
                          child: Text('0',style: TextStyle(fontSize: 19,color: Colors.black87),),
                        ),

                        Positioned(
                          top: 30,
                          left: 120,
                          child: Text('任务',style: TextStyle(fontSize: 19,color: Colors.black87),),
                        ),
                        Positioned(
                          top: 10,
                          left: 133,
                          child: Text('0',style: TextStyle(fontSize: 19,color: Colors.black87),),
                        ),
                        Positioned(
                          top: 30,
                          left: 220,
                          child: Text('关注',style: TextStyle(fontSize: 19,color: Colors.black87),),
                        ),
                        Positioned(
                          top: 10,
                          left: 235,
                          child: Text('0',style: TextStyle(fontSize: 19,color: Colors.black87),),
                        ),
                        Positioned(
                          top: 30,
                          left: 320,
                          child: Text('粉丝',style: TextStyle(fontSize: 19,color: Colors.black87),),
                        ),
                        Positioned(
                          top: 10,
                          left: 334,
                          child: Text('0',style: TextStyle(fontSize: 19,color: Colors.black87),),
                        ),

                      ],
                    ),
                    //按钮
                    Container(
                      width: window.physicalSize.width,
                      height: 10,
                      color: Color.fromARGB(10, 0, 0, 0),
                    ),

                    Container(
                        width: MediaQuery.of(context).size.width,
                        height: 500,
                        alignment: Alignment.topLeft,
                        color: Colors.white,
                        child: MediaQuery.removePadding(
                            removeTop: true,
                            context: context,
                            child: ListView(
                              scrollDirection: Axis.vertical,
                              children: <Widget>[
                                Container(
                                  height: 5,
                                ),

                                Container(
                                  width: window.physicalSize.width,
                                  height: 70,
                                  child: Stack(
                                    children: <Widget>[
                                      Positioned(
                                        left: 10,
                                        top: 5,
                                        child: Image.asset('imagesn/11.png'),
                                      ),
                                      Positioned(
                                        left: 65,
                                        top: 10,
                                        child: Text('历史',style: TextStyle(fontSize: 19,color: Colors.black87),),
                                      ),
                                      Positioned(
                                          left: 365,
                                          top: 6,
                                          child: Icon(Icons.navigate_next)
                                      ),
                                      Positioned(
                                        top: 55,
                                        child:   Container(
                                          width: window.physicalSize.width,
                                          height: 1,
                                          color: Color.fromARGB(10, 0, 0, 0),
                                        ),
                                      ),
                                      Positioned(
                                        top:-10,
                                        child: FlatButton(
                                          child: Container(
                                            width: window.physicalSize.width,
                                            height: 60,
                                          ),
                                          onPressed: (){
                                            Navigator.push(context, MaterialPageRoute(builder:
                                                (context)=>PersonalNews(title:"历史")
                                            ));

                                            //PersonalNews
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),

                                Container(
                                  width: window.physicalSize.width,
                                  height: 70,
                                  child: Stack(
                                    children: <Widget>[

                                      Positioned(
                                        left: 10,
                                        child: Image.asset('imagesn/8.png'),
                                      ),
                                      Positioned(
                                        left: 65,
                                        top: 10,
                                        child: Text('草稿箱',style: TextStyle(fontSize: 19,color: Colors.black87),),
                                      ),
                                      Positioned(
                                          left: 365,
                                          top: 6,
                                          child: Icon(Icons.navigate_next)
                                      ),
                                      Positioned(
                                        top: 55,
                                        child:   Container(
                                          width: window.physicalSize.width,
                                          height: 10,
                                          color: Color.fromARGB(10, 0, 0, 0),
                                        ),
                                      ),
                                      Positioned(
                                        top:-10,
                                        child: FlatButton(
                                          child: Container(
                                            width: window.physicalSize.width,
                                            height: 60,
                                          ),
                                          onPressed: (){
                                            Navigator.push(context, MaterialPageRoute(builder:
                                                (context)=>PersonalNews(title:"草稿箱")
                                            ));

                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),

                                Container(
                                  width: window.physicalSize.width,
                                  height: 70,
                                  child: Stack(
                                    children: <Widget>[

                                      Positioned(
                                        left: 10,
                                        top: 3,
                                        child: Image.asset('imagesn/10.png'),
                                      ),
                                      Positioned(
                                        left: 65,
                                        top: 12,
                                        child: Text('找好友',style: TextStyle(fontSize: 19,color: Colors.black87),),
                                      ),
                                      Positioned(
                                          left: 365,
                                          top: 6,
                                          child: Icon(Icons.navigate_next)
                                      ),
                                      Positioned(
                                        top: 55,
                                        child:   Container(
                                          width: window.physicalSize.width,
                                          height: 1,
                                          color: Color.fromARGB(10, 0, 0, 0),
                                        ),
                                      ),
                                      Positioned(
                                        top:-10,
                                        child: FlatButton(
                                          child: Container(
                                            width: window.physicalSize.width,
                                            height: 60,
                                          ),
                                          onPressed: (){
                                            Navigator.push(context, MaterialPageRoute(builder:
                                                (context)=>PersonalNews(title:"找好友")
                                            ));

                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),

                                Container(
                                  width: window.physicalSize.width,
                                  height: 70,
                                  child: Stack(
                                    children: <Widget>[

                                      Positioned(
                                        left: 10,
                                        top: 5,
                                        child: Image.asset('imagesn/9.png'),
                                      ),
                                      Positioned(
                                        left: 65,
                                        top: 12,
                                        child: Text('我的3D贴图',style: TextStyle(fontSize: 19,color: Colors.black87),),
                                      ),
                                      Positioned(
                                          left: 365,
                                          top: 6,
                                          child: Icon(Icons.navigate_next)
                                      ),
                                      Positioned(
                                        top: 55,
                                        child:   Container(
                                          width: window.physicalSize.width,
                                          height: 10,
                                          color: Color.fromARGB(10, 0, 0, 0),
                                        ),
                                      ),
                                      Positioned(
                                        top:-10,
                                        child: FlatButton(
                                          child: Container(
                                            width: window.physicalSize.width,
                                            height: 60,
                                          ),
                                          onPressed: (){
                                            Navigator.push(context, MaterialPageRoute(builder:
                                                (context)=>PersonalNews(title:"我的3D贴图")
                                            ));

                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width: window.physicalSize.width,
                                  height: 70,
                                  child: Stack(
                                    children: <Widget>[

                                      Positioned(
                                        left: 10,
                                        top: 5,
                                        child: Image.asset('imagesn/12.png'),
                                      ),
                                      Positioned(
                                        left: 65,
                                        top: 12,
                                        child: Text('关于我们',style: TextStyle(fontSize: 19,color: Colors.black87),),
                                      ),
                                      Positioned(
                                          left: 365,
                                          top: 6,
                                          child: Icon(Icons.navigate_next)
                                      ),
                                      Positioned(
                                        top: 55,
                                        child:   Container(
                                          width: window.physicalSize.width,
                                          height: 1,
                                          color: Color.fromARGB(10, 0, 0, 0),
                                        ),
                                      ),
                                      Positioned(
                                        top:-10,
                                        child: FlatButton(
                                          child: Container(
                                            width: window.physicalSize.width,
                                            height: 60,
                                          ),
                                          onPressed: (){
                                            Navigator.push(context, MaterialPageRoute(builder:
                                                (context)=>PersonalNews(title:"关于我们")
                                            ));

                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),

                              ],
                            )
                        )

                    )



                  ],
                )
            )
    );
  }

}




class LoginPage extends StatefulWidget {
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextStyle TheStyle = TextStyle(
      color: Colors.white, fontSize: 17.0, fontWeight: FontWeight.w500);
  var usernameController = new TextEditingController();
  var userPwdController = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
        child: Center(
            child: new Column(
              //MainAxisSize在主轴方向占有空间的值，默认是max。还有一个min
                mainAxisSize: MainAxisSize.max,
                //MainAxisAlignment：主轴方向上的对齐方式，会对child的位置起作用，默认是start。
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Container(
                    height: 25,),
                  Container(
                      width: 410,
                      height: 62,
                      padding: new EdgeInsets.fromLTRB(10, 0.0, 10.0, 10.0),
                      child: Container(
                        child: Image.network(
                            'https://cdn.nlark.com/yuque/0/2019/png/164272/1556429404436-33f4dea0-2d03-4d5a-b991-fa28eca50ffb.png'),
                        color: Color.fromRGBO(150, 180, 230, 1),
                      )),
                  Padding(
                    padding: EdgeInsets.all(10.0),
                    // 用户名输入框
                    child: TextField(
                      // 控制器
                      controller: usernameController,
                      // maxLength: 11,
                      // maxLines: 1,
                      // 是否自动更正
                      autocorrect: false,
                      // 是否自动对焦
                      autofocus: false,
                      decoration: new InputDecoration(
                        suffixText: "可以用学号",
                        suffixStyle: TextStyle(fontSize: 12.0, fontWeight: FontWeight.w300,color: Colors.blueGrey[300]),
                        labelText: "用户名",
                        // labelStyle: TextStyle(fontSize: 17.0, fontWeight: FontWeight.w600,color: Colors.blueGrey[300]),
                        icon: new Icon(Icons.filter_tilt_shift,color: Colors.lightBlueAccent[300],),
                      ),
                      onChanged: (text) {
                        //内容改变的回调
                        print('change $text');
                      },
                      onSubmitted: (text) {
                        //内容提交(按回车)的回调
                        print('submit $text');
                      },
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.all(10.0),
                    child: TextField(
                      //控制器
                      controller: userPwdController,
                      // 密码
                      obscureText: true,
                      decoration: new InputDecoration(
                        labelText: "密码",
                        icon: new Icon(Icons.lock_outline,color: Colors.lightBlueAccent[300],),
                      ),
                      onChanged: (text) {
                        //内容改变的回调
                        print('change $text');
                      },
                      onSubmitted: (text) {
                        //内容提交(按回车)的回调
                        print('submit $text');
                      },
                    ),
                  ),
                  Container(
                    //这里写800已经超出屏幕了，可以理解为match_parent
                    width: 800.0,
                    margin: new EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
                    padding: new EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
                    //类似cardview
                    child: new Card(
                      color: Colors.blueAccent,
                      // 阴影
                      elevation: 3.0,
                      //按钮
                      child: new FlatButton(
                          disabledColor: Colors.grey,
                          disabledTextColor: Colors.black,
                          onPressed: () {
                            if (usernameController.text.isEmpty) {
                              //第三方的插件Toast，https://pub.dartlang.org/packages/fluttertoast
                              Fluttertoast.showToast(
                                  msg: "用户名不能为空哦",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIos: 2,
                                  backgroundColor: Colors.white70,
                                  textColor: Colors.grey[800]);
                            } else if (userPwdController.text.isEmpty) {
                              Fluttertoast.showToast(
                                  msg: "密码不能为空哦",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIos: 1,
                                  backgroundColor: Colors.white70,
                                  fontSize: 16.0,
                                  textColor: Colors.black);
                            } else {
                              //弹出对话框，里面写着账号和密码
                              showDialog(
                                  context: context,
                                  builder: (_) {
                                    return AlertDialog(
                                      title: Text("是否使用该帐号注册"),
                                      content: Text(usernameController.text +
                                          "\n" +
                                          userPwdController.text),
                                      actions: <Widget>[
                                        //对话框里面的两个按钮
                                        FlatButton(
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                            child: Text("取消")),
                                        FlatButton(
                                          //点击确定跳转到下一个界面，也就是HomePage
                                            onPressed: () {
                                              MyApp.ascendproces=true;
                                              MyApp.paginationname=usernameController.text;
                                              MyApp().saveString("paginationname", usernameController.text);
                                              MyApp().saveBool("ascendproces", true);
                                              _PaginationType4._instance.UpdateState();
                                              Navigator.of(context).pop();
//                                              Navigator.push(
//                                                  context,
//                                                  MaterialPageRoute(
//                                                      builder: (context) =>
//                                                      new MyHomePage()));
                                            },
                                            child: Text("确定")),
                                      ],
                                    );
                                  });
                            }
                          },
                          child: new Padding(
                            padding: new EdgeInsets.all(10.0),
                            child: new Text(
                              '登录',
                              style: new TextStyle(
                                  color: Colors.white, fontSize: 16.0),
                            ),
                          )),
                    ),
                  )
                ])));
  }
}


