import 'package:flutter/material.dart';
import 'package:flutter/material.dart' as prefix0;
import 'package:flutter_swiper/flutter_swiper.dart';
import 'HeroListClass.dart';
import 'SimpleMUPage.dart';
import 'dart:ui';
import 'main.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

//首页类
class PaginationType1 extends StatelessWidget{

  @override

  Widget build(BuildContext context){

    return Scaffold(
      body: ListView(
        scrollDirection: Axis.vertical,
        physics: new NeverScrollableScrollPhysics(),//禁用滚动事件
            children: <Widget>[

//              Container(
//                height: 10,
//              ),
              //设置头像
              personalHoad(),
              //播图
              PaginationShow(),
              Container(
                height: 5,
              ),
              //热门电影
              Movieshow(),

            ],
            //child:Text('欢迎来到首页'),
      ),
        drawer: new Mydrawer(),
    );

  }
}

//头像类
class personalHoad extends StatelessWidget{

  final List<Tab> _mtabs=<Tab>[
    Tab(text: 'tab1',icon: Icon(Icons.airline_seat_flat),),
    Tab(text: 'tab2',icon: Icon(Icons.airline_seat_flat),),
    Tab(text: 'tab3',icon: Icon(Icons.airline_seat_flat),),
  ];
  @override

  Widget build(BuildContext context){

    return Container(
          child:Row(
            children: <Widget>[
              Container(
                width: 350,
                  height: 60,
                  child:Stack(
                    children: <Widget>[

                      Positioned(
                        left: 15.0,
                         child:GestureDetector(
                            child: Image.asset('imagesn/1.png',
                              width: 45,
                              height: 45,
                            ),
                            onTap: (){
                              Scaffold.of(context).openDrawer();
                            },
                          )
                      ),
                      Positioned(
                        left: 140.0,
                        top: 10.0,
                          child: GestureDetector(
                            child: Image.asset('imagesn/2.png',

                            ),
                            onTap: (){
                              MainBottomNavigation.instance.UpdateState();
                            },
                          )
                      ),
                    ],
                  )
              ),

            ],
          )
    );

  }
}

//图片展示类
class PaginationShow extends StatefulWidget {
  PaginationShow({Key key}) : super(key: key);

  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<PaginationShow> {
  List<Map> _swiperDataSources = [
    {
      "imgUrl":
      "http://pub.tcc-interiors.com/yypic/Uploads/slide/2019-11-11/5dc97af564250.jpg",
      "linkUrl":
      "http://pub.tcc-interiors.com/yypic/Uploads/slide/2019-11-11/5dc97af564250.jpg"
    },
    {
      "imgUrl": "http://pub.tcc-interiors.com/yypic/Uploads/slide/2019-11-26/5ddd1c3ccd933.jpg",
      "linkUrl": "http://pub.tcc-interiors.com/yypic/Uploads/slide/2019-11-26/5ddd1c3ccd933.jpg"
    },
    {
      "imgUrl":
      "http://pub.tcc-interiors.com/yypic/Uploads/slide/2019-09-19/5d83913860149.jpg",
      "linkUrl":
      "http://pub.tcc-interiors.com/yypic/Uploads/slide/2019-09-19/5d83913860149.jpg"
    },
    {
      "imgUrl":
      "http://pub.tcc-interiors.com/yypic/Uploads/slide/2019-12-01/5de342e569ada.jpg",
      "linkUrl":
      "http://pub.tcc-interiors.com/yypic/Uploads/slide/2019-12-01/5de342e569ada.jpg"
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: <Widget>[
          Container(
            width: double.infinity, //宽度自适应
            height: 180,
            child: //AspectRatio可以调整子元素的宽高比
            AspectRatio(
              aspectRatio: 16 / 9, //子元素的宽高比
              child: Swiper(
                itemBuilder: (BuildContext context, int index) {
                  return new Image.network(
                    _swiperDataSources[index]["imgUrl"],
                    fit: BoxFit.fill,
                  );
                },
                itemCount: _swiperDataSources.length,
//                //分页指示器
//                pagination: SwiperPagination(
//                  alignment: Alignment.bottomLeft,//分页指示器的位置
//                  margin: EdgeInsets.all(10),//分页指示器与容器边框的距离
//                  builder: SwiperPagination.fraction,//分页指示器样式
//                ),
                //控制按钮
                control: SwiperControl(
                  iconPrevious: Icons.arrow_back_ios,//上一页的IconData
                  iconNext: Icons.arrow_forward_ios,//下一页的IconData
                  color: Colors.pink,//控制按钮的颜色
                  size: 30.0,//控制按钮的大小
                  padding: EdgeInsets.all(0.0),//控制按钮与容器的距离
                ),
                scrollDirection: Axis.horizontal,//滚动方向（默认是水平）
                loop: false,//是否开启无线轮播模式
                index: 1,//初始的下标位置
                autoplay: true,//是否自动播放
                //当用户手动拖拽或者自动播放引起下标改变的时候调用
                onIndexChanged: (index){
                  // print(index);
                },
                //当用户点击某个轮播的时候调用
                onTap: (index){
                  print("用户点击$index");
                  if(index==0){
                    Navigator.push(context, MaterialPageRoute(//1
                        builder:(context)=>SimpleMupageBoss(spPlayerIdx:21)));
                  }else if(index==1){
                    Navigator.push(context, MaterialPageRoute(//2
                        builder:(context)=>SimpleMupageBoss(spPlayerIdx:20)));
                  }else if(index==2){
                    Navigator.push(context, MaterialPageRoute(//3
                        builder:(context)=>SimpleMupageBoss(spPlayerIdx:18)));
                  }else if(index==3){
                    Navigator.push(context, MaterialPageRoute(//4
                        builder:(context)=>SimpleMupageBoss(spPlayerIdx:19)));
                  }


                },
                duration: 600,//动画时间，单位是毫秒
              ),
            ),
          )
        ],
      ),
    );
  }
}


//电影展示

class Movieshow extends StatelessWidget{

  @override

  Widget build(BuildContext context){
    return Container(
        alignment: Alignment.topLeft,//double.infinity
        height: window.physicalSize.height/3.5,
        width: MediaQuery.of(context).size.width,
        //color: Color.fromARGB(250, 34, 28, 51),
        child:MediaQuery.removePadding(
        removeTop: true,
        context: context,
        child: ListView(
          //  physics: new NeverScrollableScrollPhysics(),//禁用滚动事件
          scrollDirection: Axis.vertical,
          children: <Widget>[
            //热播视频-----------------------
            Stack(
              children: <Widget>[
                Positioned(
                  child: Image.asset('imagesn/6.png'),
                ),
                Positioned(
                  left: 40.0,
                  top:5.0,
                  child:   Container(
                    alignment: Alignment.topLeft,
                    child: Text('热播视频',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                  ),
                ),
                Positioned(
                  left: 300.0,
                  top:7.0,
                  child:   Container(
                      alignment: Alignment.topLeft,
                      child: GestureDetector(
                        child: Text('查看更多',style: TextStyle(fontSize: 16),),
                        onTap: (){
                          MainBottomNavigation.instance.UpdateState();
                        },
                      )
                  ),
                ),
                Positioned(
                    left: 360,
                    top: 7.0,
                    child: GestureDetector(
                      child: Icon(Icons.navigate_next),
                      onTap: (){
                        MainBottomNavigation.instance.UpdateState();
                      },
                    )
                ),

              ],
            ),

            Container(
              height: 5,
            ),
            //热播一组
            Stack(
              children: <Widget>[
                Container(
                  height: 180,

                ),
                Positioned(
                    left: 5,
                    child: GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:0)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:  Image.network(
                              JSListClass.JsList[0]['imname'],
                              fit: BoxFit.cover,
                              width: MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )


                        ],

                      ),

                    )
                ),
                Positioned(
                    left: 10.0,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[0]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),

                Positioned(
                    left:  MediaQuery.of(context).size.width/4,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[0]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/2.96,
                    child:  GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:1)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.network(
                              JSListClass.JsList[1]['imname'],
                              fit: BoxFit.cover,
                              width: MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )



                        ],

                      ),

                    )
                ),
                Positioned(
                    left:  MediaQuery.of(context).size.width/2.96,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[1]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),
                Positioned(
                    left:  MediaQuery.of(context).size.width/1.74,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[1]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left:  MediaQuery.of(context).size.width/1.5,
                    child:  GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:2)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:Image.network(
                              JSListClass.JsList[2]['imname'],
                              fit: BoxFit.cover,
                              width: MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )

                        ],

                      ),

                    )
                ),
                Positioned(
                    left:  MediaQuery.of(context).size.width/1.11,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[2]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left:  MediaQuery.of(context).size.width/1.5,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[2]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),

              ],
            ),

            //热播二组
            Stack(
              children: <Widget>[
                Container(
                  height: 180,

                ),
                Positioned(
                    left: 5,
                    child: GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:3)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:Image.network(
                              JSListClass.JsList[3]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )
                        ],

                      ),

                    )
                ),
                Positioned(
                    left: 10.0,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[3]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/4,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[3]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/2.96,
                    child:  GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:4)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:Image.network(
                              JSListClass.JsList[4]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )



                        ],

                      ),

                    )
                ),
                Positioned(
                    left:  MediaQuery.of(context).size.width/1.74,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[4]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/2.96,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[4]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),

                Positioned(
                    left: MediaQuery.of(context).size.width/1.5,
                    child:  GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:5)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:Image.network(
                              JSListClass.JsList[5]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )



                        ],

                      ),

                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/1.11,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[5]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/1.5,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[5]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),

              ],
            ),


            //热播电视剧-----------------------
            Stack(
              children: <Widget>[
                Positioned(
                  child: Image.asset('imagesn/3.png'),
                ),
                Positioned(
                  left: 40.0,
                  top:5.0,
                  child:   Container(
                    alignment: Alignment.topLeft,
                    child: Text('热播电视剧',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                  ),
                ),
                Positioned(
                  left: 300.0,
                  top:7.0,
                  child:   Container(
                      alignment: Alignment.topLeft,
                      child: GestureDetector(
                        child: Text('查看更多',style: TextStyle(fontSize: 16),),
                        onTap: (){
                          MainBottomNavigation.instance.UpdateState();
                        },
                      )
                  ),
                ),
                Positioned(
                    left: 360,
                    top: 7.0,
                    child: GestureDetector(
                      child: Icon(Icons.navigate_next),
                      onTap: (){
                        MainBottomNavigation.instance.UpdateState();
                      },
                    )
                ),

              ],
            ),

            Container(
              height: 5,
            ),
            //热播一组
            Stack(
              children: <Widget>[
                Container(
                  height: 180,

                ),
                Positioned(
                    left: 5,
                    child: GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:6)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:  Image.network(
                              JSListClass.JsList[6]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )


                        ],

                      ),

                    )
                ),
                Positioned(
                    left: 10.0,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[6]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),

                Positioned(
                    left: MediaQuery.of(context).size.width/4,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[6]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/2.96,
                    child:  GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:7)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.network(
                              JSListClass.JsList[7]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )



                        ],

                      ),

                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/2.96,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[7]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),
                Positioned(
                    left:  MediaQuery.of(context).size.width/1.74,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[7]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/1.5,
                    child:  GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:8)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:Image.network(
                              JSListClass.JsList[8]['imname'],
                              fit: BoxFit.cover,
                              width: MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )

                        ],

                      ),

                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/1.11,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[8]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/1.5,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[8]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),

              ],
            ),

            //热播二组
            Stack(
              children: <Widget>[
                Container(
                  height: 180,

                ),
                Positioned(
                    left: 5,
                    child: GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:9)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:Image.network(
                              JSListClass.JsList[9]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )
                        ],

                      ),

                    )
                ),
                Positioned(
                    left: 10.0,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[9]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/4,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[9]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left:MediaQuery.of(context).size.width/2.96,
                    child:  GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:10)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:Image.network(
                              JSListClass.JsList[10]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )



                        ],

                      ),

                    )
                ),
                Positioned(
                    left:  MediaQuery.of(context).size.width/1.74,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[10]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/2.96,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[10]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),

                Positioned(
                    left: MediaQuery.of(context).size.width/1.5,
                    child:  GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:11)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:Image.network(
                              JSListClass.JsList[11]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )



                        ],

                      ),

                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/1.11,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[11]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/1.5,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[11]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),

              ],
            ),


            //热播动漫-----------------------
            Stack(
              children: <Widget>[
                Positioned(
                  child: Image.asset('imagesn/4.png'),
                ),
                Positioned(
                  left: 40.0,
                  top:5.0,
                  child:   Container(
                    alignment: Alignment.topLeft,
                    child: Text(' 热播动漫',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                  ),
                ),
                Positioned(
                  left: 300.0,
                  top:7.0,
                  child:   Container(
                      alignment: Alignment.topLeft,
                      child: GestureDetector(
                        child: Text('查看更多',style: TextStyle(fontSize: 16),),
                        onTap: (){
                          MainBottomNavigation.instance.UpdateState();
                        },
                      )
                  ),
                ),
                Positioned(
                    left: 360,
                    top: 7.0,
                    child: GestureDetector(
                      child: Icon(Icons.navigate_next),
                      onTap: (){
                        MainBottomNavigation.instance.UpdateState();
                      },
                    )
                ),

              ],
            ),

            Container(
              height: 5,
            ),
            //热播一组
            Stack(
              children: <Widget>[
                Container(
                  height: 180,

                ),
                Positioned(
                    left: 5,
                    child: GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:12)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:  Image.network(
                              JSListClass.JsList[12]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )


                        ],

                      ),

                    )
                ),
                Positioned(
                    left: 10.0,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[12]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),

                Positioned(
                    left: MediaQuery.of(context).size.width/4,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[12]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/2.96,
                    child:  GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:13)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.network(
                              JSListClass.JsList[13]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )



                        ],

                      ),

                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/2.96,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[13]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),
                Positioned(
                    left:  MediaQuery.of(context).size.width/1.74,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[13]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/1.5,
                    child:  GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:14)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:Image.network(
                              JSListClass.JsList[14]['imname'],
                              fit: BoxFit.cover,
                              width: MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )

                        ],

                      ),

                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/1.11,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[14]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/1.5,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[14]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),

              ],
            ),

            //热播二组
            Stack(
              children: <Widget>[
                Container(
                  height: 180,

                ),
                Positioned(
                    left: 5,
                    child: GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:15)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:Image.network(
                              JSListClass.JsList[15]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )
                        ],

                      ),

                    )
                ),
                Positioned(
                    left: 10.0,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[15]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/4,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[15]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/2.96,
                    child:  GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:16)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:Image.network(
                              JSListClass.JsList[16]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )



                        ],

                      ),

                    )
                ),
                Positioned(
                    left:  MediaQuery.of(context).size.width/1.74,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[16]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/2.96,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[16]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),

                Positioned(
                    left: MediaQuery.of(context).size.width/1.5,
                    child:  GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(//切换页面
                            builder:(context)=>SimpleMupageBoss(spPlayerIdx:17)
                        ));
                      },

                      child: Stack(
                        children: <Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child:Image.network(
                              JSListClass.JsList[17]['imname'],
                              fit: BoxFit.cover,
                              width:  MediaQuery.of(context).size.width/3.2,
                              height: 150,
                            ),
                          )



                        ],

                      ),

                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/1.11,
                    bottom: 30.0,
                    child: Container(
                        width: 30,
                        height: 20,
                        color: Colors.black,
                        child: Text(JSListClass.JsList[17]['score'],
                            style: TextStyle(
                                fontSize: 18.0,color: Colors.deepOrange,fontWeight: FontWeight.w700))
                    )
                ),
                Positioned(
                    left: MediaQuery.of(context).size.width/1.5,
                    bottom: 5.0,
                    child: Text(JSListClass.JsList[17]['name'],
                        style: TextStyle(
                            fontSize: 18.0))
                ),

              ],
            ),


          ],
        )
        )


    );

  }

}




//等待数据刷新类
class Refreshwaitrce extends StatelessWidget{

  @override

  Widget build(BuildContext context){
    return Scaffold(
        body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Image.asset('imagesn/flash.png',fit: BoxFit.fill,)
        )
    );

  }
}

//加载动画
class ImagesAnim extends StatefulWidget {
  final List<Image> imageCaches;



  final double width;
  final double height;
  final Color backColor;

  ImagesAnim(this.imageCaches,this.width, this.height, this.backColor, {Key key})
      :
        super(key: key);

  @override
  State<StatefulWidget> createState() {
    imageCaches.add(Image.asset("imagesn/loading_2.png",width: 50,height: 50,));
    imageCaches.add(Image.asset("imagesn/loading_3.png",width: 50,height: 50,));
    imageCaches.add(Image.asset("imagesn/loading_4.png",width: 50,height: 50,));
    imageCaches.add(Image.asset("imagesn/loading_2.png",width: 50,height: 50,));
    return new _WOActionImageState();
  }
}

class _WOActionImageState extends State<ImagesAnim> {
  bool _disposed;
  Duration _duration;
  int _imageIndex;
  Container _container;

  @override
  void initState() {
    super.initState();
    _disposed = false;
    _duration = Duration(milliseconds: 200);
    _imageIndex = 0;
    _container = Container(height: widget.height, width: widget.width);
    _updateImage();
  }

  void _updateImage() {
    if (_disposed || widget.imageCaches.isEmpty) {
      return;
    }

    setState(() {
      if (_imageIndex >= widget.imageCaches.length) {
        _imageIndex = 0;
      }
      _container = Container(
          child: widget.imageCaches[_imageIndex],
        );
      _imageIndex++;
    });
    Future.delayed(_duration, () {
      _updateImage();
    });
  }

  @override
  void dispose() {
    super.dispose();
    _disposed = true;
    widget.imageCaches.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
          width: MediaQuery.of(context).size.width, height: 200,
          child: _container
      )
    );
  }
}















//抽屉菜单

class Mydrawer extends StatelessWidget{
  @override
  const Mydrawer({Key key}):super(key:key);

  Widget build(BuildContext context){

    return Drawer(
      child: MediaQuery.removePadding(context: context,removeTop: true, child:
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                height: 100,
              ),
              Stack(
                children: <Widget>[
                  Align(
                    alignment: Alignment.lerp(Alignment.topLeft, Alignment.bottomRight, 0.1),

                    child: Image.asset('imagesn/1.png',
                      width: 80,
                      height: 80,
                    ),
                  ),

                  Positioned(
                      left: 130,
                      bottom:30,
                      child: Text('黄脸婆',
                          style: TextStyle(
                              fontSize: 18.0))
                  )

                ],
              ),



//              Padding(
//                padding: const EdgeInsets.symmetric(horizontal: 16.0),
//                child: Row(
//                    children: <Widget>[
//                      Text('wendux',style: prefix0.TextStyle(fontWeight: FontWeight.bold),)
//
//                    ],
//                ),
//              ),

            ],
          )
      ),
    );
  }

}



















