import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'dart:math';
class ChewieVideoDemo extends StatefulWidget {
  ChewieVideoDemo({Key key,@required this.spPlayerIdx}) : super(key: key);
  final int spPlayerIdx;
  _ChewieVideoDemoState createState() => _ChewieVideoDemoState();
}

class _ChewieVideoDemoState extends State<ChewieVideoDemo> {
  VideoPlayerController videoPlayerController;
  ChewieController chewieController;
  List<String> spPlayerName=['https://media.w3.org/2010/05/sintel/trailer.mp4',
    'http://www.w3school.com.cn/example/html5/mov_bbb.mp4',
    'https://www.w3schools.com/html/movie.mp4',
    'http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4',
    'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8',
    'http://vfx.mtime.cn/Video/2019/02/04/mp4/190204084208765161.mp4',
  ];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    videoPlayerController = VideoPlayerController.network(
        'http://cd-download.weiyun.com/ftn_handler/3e0b3714a1088fc21b053ad4b054ff2eb4c5571d400086e52314d2e8eb28d2cf/%E5%B9%B2%E9%A2%84.mp4');

    chewieController = ChewieController(
      videoPlayerController: videoPlayerController,
      aspectRatio: 3 / 2,
      autoPlay: true,
      looping: true,
    );
  }

  /*销毁*/
  @override
  void dispose() {
    print('dispose');
    videoPlayerController.dispose();
    chewieController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('精彩直播视频'),
      ),
      body: Center(
          child: ListView(
            children: <Widget>[
              Chewie(
                controller: chewieController,
              ),

              Column(
                  children: <Widget>[
                    Card(
                      child: Container(
                        width: 500,
                        height: 35,
                        child: Stack(
                          children: <Widget>[
                            Positioned(
                              left: 20,
                              top: 5,
                              child: Text('简介',style: TextStyle(fontSize: 18.0,color: Colors.black87),),
                            ),
                            Positioned(
                              left: 80,
                              top: 5,
                              child: Text('评论 196077',style: TextStyle(fontSize: 18.0,color: Colors.black87),),
                            ),
                            Positioned(
                              left: 250,
                              top: 5,
                              child: Container(
                                width: 100,
                                height: 25,
                                color: Colors.black38,
                                child: Text(' 点我发弹幕',style: TextStyle(fontSize: 18.0,color: Colors.black87),),
                              )
                            ),
                          ],
                        ),
                      ),
                    ),
                    Card(
                      child: Container(
                        width: 500,
                        height: 400,
                        child: Stack(
                          children: <Widget>[
                            ExpansionTile(
                                title:Text('梦塔·雪谜城',style: TextStyle(color: Colors.black,fontSize: 20.0),),
                                backgroundColor: Colors.black,
                                children: <Widget>[
                                  ListTile(

                                      title:Stack(
                                        children: <Widget>[
                                          Text('在线人数：478万'),
                                          Positioned(
                                            left: 150,
                                            child:  Text('发言人数：124万')
                                            ,
                                          )
                                        ],
                                      ),
                                      subtitle:Text('你是第56个发言人',style: TextStyle(color: Colors.black))
                                  )
                                ],
                                initiallyExpanded: true,
                              ),
                                Positioned(
                                  top: 140.0,
                                  left: 15.0,
                                  child: Text('更新：12集全 ',style: TextStyle(color: Colors.teal,fontSize: 20.0),),
                                ),
                                Positioned(
                                  top: 140.0,
                                  left: 180.0,
                                  child: Text('作者：-- ',style: TextStyle(color: Colors.teal,fontSize: 20.0),),
                                ),
                                Positioned(
                                  top: 180.0,
                                  left: 15.0,
                                  child: Text('配音：-- ',style: TextStyle(color: Colors.teal,fontSize: 20.0),),
                                ),
                              Positioned(
                                top: 180.0,
                                left: 180.0,
                                child: Text('地区：中国内地 ',style: TextStyle(color: Colors.teal,fontSize: 20.0),),
                              ),
                            Positioned(
                              top: 220.0,
                              left: 15.0,
                              child: Text('类型：热血 ',style: TextStyle(color: Colors.teal,fontSize: 20.0),),
                            ),
                            Positioned(
                              top: 260.0,
                              left: 15.0,
                              child: Text('现实中一切极端的梦境，都凝聚着可怕的能量。',
                                maxLines: 1,textAlign:TextAlign.left,style: TextStyle(
                                  fontSize:18.0,
                                  color:Colors.black,
                                  decoration:TextDecoration.underline,
                                  decorationStyle:TextDecorationStyle.solid,
                                ),),
                            ),
                            Positioned(
                              top: 285.0,
                              left: 15.0,
                              child: Text('唯有将这些梦境送入异次元世界——梦界化消，',
                                maxLines: 1,textAlign:TextAlign.left,style: TextStyle(
                                  fontSize:18.0,
                                  color:Colors.black,
                                  decoration:TextDecoration.underline,
                                  decorationStyle:TextDecorationStyle.solid,
                                ),),
                            ),
                            Positioned(
                              top: 315.0,
                              left: 15.0,
                              child: Text('才能避免这些能量对现实世界造成扭曲动荡……',
                                maxLines: 1,textAlign:TextAlign.left,style: TextStyle(
                                  fontSize:18.0,
                                  color:Colors.black,
                                  decoration:TextDecoration.underline,
                                  decorationStyle:TextDecorationStyle.solid,
                                ),),
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
//              RaisedButton(
//                child: Text("切换视频"),
//                onPressed: () {
//                  print(Random(100));
//                  videoPlayerController.pause();
//                  setState(() {
//
//                    videoPlayerController = VideoPlayerController.network(
//                        spPlayerName[widget.spPlayerIdx]);
//                    chewieController = ChewieController(
//                      videoPlayerController: videoPlayerController,
//                      aspectRatio: 3 / 2,
//                      autoPlay: true,
//                      looping: true,
//                    );
//                  });
//                },
//              )
            ],
          )),
    );
  }
}