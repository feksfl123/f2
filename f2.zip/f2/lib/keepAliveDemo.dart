import 'package:flutter/material.dart';

class KeepAliveeDemo extends StatefulWidget{
  _KeepAliveeDemo createState()=>_KeepAliveeDemo();
}

class _KeepAliveeDemo extends State<KeepAliveeDemo> with AutomaticKeepAliveClientMixin{

  int _counter=0;

  @override
  bool get wantKeepAlive => true;

  void _incrementCounter()=>setState((){_counter++;});


  @override

  Widget build(BuildContext context){
    return Scaffold(
       body: Container(
         child: ListView(
           children: <Widget>[
            Container(
               child: Image.network(
                  'http://game.gtimg.cn/images/yxzj/zlkdatasys/images/image/20190705/8af634c6cec787c24db02834a6ae5f40.jpg',
               fit: BoxFit.fitWidth,
               ),
              width: 500,
              height: 200,
              color: Colors.lightBlueAccent,

            ),

           FeaturedButton(),//调用按钮类
             Container(
               child: OutlineButton(
                 child: Text('重点推荐',
                   style: TextStyle(color: Colors.deepPurple),
                 ),
                 onPressed: () {},
                 //color: Colors.purple,
               ),
             ),

           TabeLabelList(),//调用文字显示类
             Container(//占位

               width: 500,
               height: 30,
              // color: Colors.lightBlueAccent,
             ),
             Container(

               child: OutlineButton(
                 child: Text('热门英雄',
                   style: TextStyle(color: Colors.deepPurple),
                 ),
                 onPressed: () {},
                 //color: Colors.purple,
               ),

             ),
           ],

         ),
       ),
//      floatingActionButton: FloatingActionButton(
//        onPressed: _incrementCounter,
//        tooltip: 'Increment',
//        child: Icon(Icons.add),
//      ),
    );
  }
}

//文字显示类
class TabeLabelList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return
        Container(

        );

  }
}



//按钮类
class FeaturedButton extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return
       Container(

      );

  }
}








