
import 'package:flutter/material.dart';
import 'main.dart';
import 'dart:ui';
import 'SimpleMUPage.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
class PersonalNews extends StatefulWidget{
 final String title;

 PersonalNews({Key key,@required this.title}):super(key:key);

  _PersonalNews createState()=> _PersonalNews();

}

class _PersonalNews extends State<PersonalNews>{

  @override

  Widget build(BuildContext context){
    Widget APPContext;

    if(widget.title=="历史"){
      APPContext=Scaffold(
        appBar: PreferredSize(
            child: AppBar(
              title: Text(widget.title),
              brightness: Brightness.light,
              backgroundColor: Colors.deepPurpleAccent,
            ),
            preferredSize: Size.fromHeight(45)),
          body:  Center(
            child: Text('暂无历史记录',style: TextStyle(color: Colors.black,fontSize: 18)),
          ),
//        body: Center(
//          child: ListView(
//            children: <Widget>[
//              //显示所有电影
//
////              Container(
////                  height: window.physicalSize.height/3.5,
////                  child: AnimationLimiter(
////                    child: GridView.count(
////                        crossAxisCount: 3,
////                        childAspectRatio: 0.7,
////                        children: List.generate(10,(index){
////                          return AnimationConfiguration.staggeredGrid(position: index, columnCount: 2,duration: const Duration(milliseconds: 375), child:
////                          SlideAnimation(
////                            verticalOffset: 100.0,
////                            child: FadeInAnimation(
////                                child:
////                                Center(
////                                  child: Stack(
////                                    children: <Widget>[
////                                      Container(
////                                        height: 200.0,
////                                      ),
////                                      Text('你好啊'),
////                                      GestureDetector(
////                                        onTap: (){
//////                                          Navigator.push(context, MaterialPageRoute(//切换页面
//////                                              builder:(context)=>SimpleMupageBoss(spPlayerIdx:index)
//////                                          ));
////
////                                        },
//////                                        child: ClipRRect(
//////                                          borderRadius: BorderRadius.circular(1),
//////                                          child:  Image.network(
//////                                            PaginatList[index]['imname'],
//////                                            fit: BoxFit.cover,
//////                                            width: 130,
//////                                            height: 170,
//////                                          ),
//////                                        ),
////                                      ),
////
//////                                      Positioned(
//////                                          left: 10.0,
//////                                          bottom: 0.0,
//////                                          child: Text(PaginatList[index]['name'],
//////                                              style: TextStyle(
//////                                                  fontSize: 18.0))
//////                                      ),
////                                    ],
////
////                                  ),
////                                )
////                            ),
////                          )
////                          );
////
////                        },)
////                    ),
////                  )
////              ),
//              //Pre
//            ],
//          )
//        ),
      );
    } else if(widget.title=="草稿箱") {
      APPContext=Scaffold(
        appBar: PreferredSize(
            child: AppBar(
              title: Text(widget.title),
              brightness: Brightness.light,
              backgroundColor: Colors.deepPurpleAccent,
            ),
            preferredSize: Size.fromHeight(45)),
        body: Center(
          child: Text("暂无草稿箱",style: TextStyle(color: Colors.black,fontSize: 18),),
        ),
      );
    }
    else if(widget.title=="找好友"){
      APPContext=Scaffold(
        appBar: PreferredSize(
            child: AppBar(
              title: Text(widget.title),
              brightness: Brightness.light,
              backgroundColor: Colors.deepPurpleAccent,
            ),
            preferredSize: Size.fromHeight(45)),
        body: Center(
          child: Text("附近没有人",style: TextStyle(color: Colors.black,fontSize: 18),),
        ),
      );
    }
    else if(widget.title=="我的3D贴图"){
      APPContext=Scaffold(
        appBar: PreferredSize(
            child: AppBar(
              title: Text(widget.title),
              brightness: Brightness.light,
              backgroundColor: Colors.deepPurpleAccent,
            ),
            preferredSize: Size.fromHeight(45)),
        body: Center(
          child: Text("暂无新的3D贴图",style: TextStyle(color: Colors.black,fontSize: 18),),
        ),
      );
    }
    else if(widget.title=="关于我们"){
      APPContext=Scaffold(
        appBar: PreferredSize(
            child: AppBar(
              title: Text(widget.title),
              brightness: Brightness.light,
              backgroundColor: Colors.deepPurpleAccent,
            ),
            preferredSize: Size.fromHeight(45)),
        body: Center(
          child: Container(
            padding: EdgeInsets.all(10),
            alignment: Alignment.lerp(Alignment.topLeft, Alignment.center, 0.1),
            child: Text("我们的使命是整合全球信息，供大众使用，让人人受益技术最美好的地方在于，让我们看到世界因此而变得更美好。",
              style: TextStyle(color: Colors.black,fontSize: 18),),
          ),
        )
      );
    }

    return APPContext;
  }
}
