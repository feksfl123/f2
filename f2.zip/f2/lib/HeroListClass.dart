import 'package:flutter/material.dart';
// json
import 'dart:convert';
// 异步 Future
import 'dart:async';
import 'tyinTypeClass.dart';
import 'Personjx.dart';
import 'package:flutter/services.dart';

// 读取 assets 文件夹中的 person.json 文件
Future<String> _loadPersonJson() async {
  return rootBundle.loadString('json/perosn.json');

}

// 将 json 字符串解析为 Person 对象
void decodePerson() async {

  fromJson(str) {
    return Person;//Person(name: json['name'], age: json['age'], height: json['height']);
  }

  // 获取本地的 json 字符串
  String personJson = await _loadPersonJson();

  // 解析 json 字符串，返回的是 Map<String, dynamic> 类型
  final jsonMap = json.decode(personJson);

  print('jsonMap runType is ${jsonMap.runtimeType}');
  JSListClass.JsList=jsonMap;
 // List f1=jsonMap[6]['movie'];
//  var f2=f1[0];
//  var f43=f2['name'];
  print('11');

}

class JSListClass{
  static  List JsList=[];
}

