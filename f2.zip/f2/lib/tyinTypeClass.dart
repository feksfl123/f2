import 'dart:ffi';

import 'package:flutter/material.dart';
import 'HeroListClass.dart';
import 'HeroIntroduction.dart';

class tyinTypeClass extends StatefulWidget{
  _tyinTypeClass createState()=>_tyinTypeClass();
}
//小分类按钮组件类

class _tyinTypeClass extends State<tyinTypeClass> with AutomaticKeepAliveClientMixin{

  //控制分栏
  int _typeCounter=1;

  @override
  bool get wantKeepAlive=>true;

  void _incrementCounter()=>setState((){_typeCounter++;});

  @override
  Widget build(BuildContext context){

    return Container(
      child: ListView(
        children: <Widget>[
          EachView(),//小分栏
        ],
      ),
      width: 400,
      height: 700,
      //color: Colors.black,∂
      //padding: const EdgeInsets.all(1),
    );
    return Container(

         child: ListView(
           children: <Widget>[
             EachView(),//小分栏
           ],
         ),
          width: 400,
          height: 520,
       //color: Colors.black,∂
     //padding: const EdgeInsets.all(1),
    );
  }

}

class HoreTypeClass {
  static int horeType=1;
  static int returnHore(){
    return horeType;
  }
  static Void SetHore(int num){
    horeType=num;
  }
}


class EachView extends StatefulWidget {
  Color _button1=Color.fromARGB(255, 76, 47, 104);
  Color _button2=Colors.white;
  Color _button3=Colors.white;
  Color _button4=Colors.white;

  //EachView(this._title);
  EachView(){

  }

  @override
  ListButtonClass createState() => ListButtonClass();
}


class ListButtonClass extends State<EachView> {
  final List<String> strTypeLabel=['最火英雄','最火出装','最火攻略','最火大服'];
  final List heroList=JSListClass.JsList;
  List<Widget> _heroListScene=List();
  void initState(){
    _heroListScene
      ..add(HeroSceneClass1())
      ..add(HeroSceneClass2())
      ..add(HeroSceneClass3())
      ..add(HeroSceneClass4());
    super.initState();


  }
  Widget build(BuildContext context){
    return Container(
      width: 300,
      height: 750,
     //color: Colors.black87,
      child: ListView(
        children: <Widget>[
          Container(height: 20),
          Row(
            children: <Widget>[
              Container(
                padding: EdgeInsets.all(1.0),
                child: Center(
                  child: Container(
                    child: FlatButton(
                      child: Text('英雄大全',
                        style: TextStyle(fontStyle: FontStyle.normal,
                            fontWeight: FontWeight.w900,
                            fontSize: 14,
                            color: Colors.cyan),
                      ),
                      color: widget._button1,
                      onPressed: () {
                        widget._button1 = Colors.lightBlueAccent;
                        setState(() {
                          widget._button1 = Color.fromARGB(255, 76, 47, 104);
                          widget._button2 = Colors.white;
                          widget._button3 = Colors.white;
                          widget._button4 = Colors.white;
                          HoreTypeClass.horeType = 1;
                        });
                      },

                    ),
                    width: 90.0,
                    height: 37.0,
                    color: Colors.deepPurpleAccent,
                  ),
                ),

                width: 90.0,
                height: 38.0,
                color: Colors.black87,

              ),
              Container(
                padding: EdgeInsets.all(1.0),
                child: Center(
                  child: Container(
                    child: FlatButton(
                      child: Text('出装攻略',
                        style: TextStyle(fontStyle: FontStyle.normal,
                            fontWeight: FontWeight.w900,
                            fontSize:  14.0,
                            color: Colors.cyan),
                      ),
                      color: widget._button2,
                      onPressed: () {
                        widget._button2 = Colors.lightGreenAccent;
                        setState(() {
                          widget._button1 = Colors.white;
                          widget._button2 = Color.fromARGB(255, 76, 47, 104);
                          widget._button3 = Colors.white;
                          widget._button4 = Colors.white;
                          HoreTypeClass.horeType = 2;
                        });
                      },

                    ),
                    width: 90.0,
                    height: 37.0,
                    color: Colors.red,
                  ),
                ),

                width: 90.0,
                height: 38.0,
                color: Colors.black87,

              ),
              Container(
                padding: EdgeInsets.all(1.0),
                child: Center(
                  child: Container(
                    child: FlatButton(
                      child: Text('英雄攻略',
                        style: TextStyle(fontStyle: FontStyle.normal,
                            fontWeight: FontWeight.w900,
                            fontSize: 14.0,
                            color: Colors.cyan),
                      ),
                      color: widget._button3,
                      onPressed: () {
                        widget._button3 = Colors.lightGreenAccent;
                        setState(() {
                          widget._button1 = Colors.white;
                          widget._button2 = Colors.white;
                          widget._button3 = Color.fromARGB(255, 76, 47, 104);
                          widget._button4 = Colors.white;
                          HoreTypeClass.horeType = 3;
                        });
                      },

                    ),
                    width: 90.0,
                    height: 37.0,
                    color: Colors.red,
                  ),
                ),

                width: 90.0,
                height: 38.0,
                color: Colors.black87,

              ),
              Container(
                padding: EdgeInsets.all(1.0),
                child: Center(
                  child: Container(
                    child: FlatButton(
                      child: Text('体验服',
                        style: TextStyle(fontStyle: FontStyle.normal,
                            fontWeight: FontWeight.w900,
                            fontSize: 14.0,
                            color: Colors.cyan),
                      ),
                      color: widget._button4,
                      onPressed: () {
                        widget._button4 = Colors.lightGreenAccent;
                        setState(() {
                          widget._button1 = Colors.white;
                          widget._button2 = Colors.white;
                          widget._button3 = Colors.white;
                          widget._button4 = Color.fromARGB(255, 76, 47, 104);
                          HoreTypeClass.horeType = 4;
                        });
                      },

                    ),
                    width: 90.0,
                    height: 37.0,
                    color: Colors.red,
                  ),
                ),

                width: 90.0,
                height: 38.0,
                color: Colors.black87,

              ),

            ],
          ),

          Container(
            child: Row(
              children: <Widget>[
                Text('                             ',
                  style: TextStyle(decoration: TextDecoration.lineThrough,
                      color: Colors.grey,
                      fontSize: 19),
                ),
                Text(strTypeLabel[HoreTypeClass.horeType-1], style: TextStyle(fontSize: 14)),
                Text('                             ',
                  style: TextStyle(decoration: TextDecoration.lineThrough,
                      color: Colors.grey,
                      fontSize: 19),
                ),
              ],
            ),
            width: 100,
            height: 50,
            //color: Colors.cyan,
            //padding: const EdgeInsets.all(0),
          ),
          _heroListScene[HoreTypeClass.horeType-1],
        ],
      ),
    );
  }
}


class HeroSceneClass1 extends StatelessWidget{
  final List heroList=JSListClass.JsList;

  @override
  Widget build(BuildContext context){
    return Container(
      alignment: Alignment.centerLeft,
      child: GridView.count(
          padding: EdgeInsets.all(10),
          crossAxisSpacing: 3,
          crossAxisCount: 3,
          mainAxisSpacing: 20,
          //宽高比
          childAspectRatio: 3.3 / 5,
          children: List.generate(heroList.length,
                  (index) {
                return Center(
                  child: Container(
                    //alignment: Alignment.topLeft,
                    child: Stack(
                      children: <Widget>[
                        Container(
                          child: Center(
                              child:
                              GestureDetector(
                                onTap: (){
                                  print(heroList[index]['name']);
//                                  MaterialPageRoute(
//                                    builder: (context)=>HeroIntroduction()
//                                  );
                                  Navigator.push(context, MaterialPageRoute(//切换页面
                                    builder:(context)=>new HeroIntroduction(HeroInList: heroList,HeroINcouu:index)
                                  ));
                                },
                                child: Container(
                                  alignment: Alignment.topLeft,
                                  child: Image.network(
                                    heroList[index]['imname'],
                                    fit: BoxFit.cover,
                                    width: 250,
                                    height: 150,
                                  ),
                                ),
                               )
                          ),
                          //color:Colors.black87
                        ),
                        Positioned(
                            left: 35.0,
                            bottom: -5.0,
                            child: Text(heroList[index]['name'],
                                style: TextStyle(
                                    fontSize: 20.0, color: Colors.purple))
                        )

                      ],
                    ),
                  ),
                );
              }
          )

      ),
      width: 500,
      height: 720,

      //color: Colors.cyan,

    );
  }
}

class HeroSceneClass2 extends StatelessWidget{

  @override
  Widget build(BuildContext context){
    return Container(
      child: Text('出装攻略'),

      alignment: Alignment.centerLeft,
      width: 500,
      height: 620,

      //color: Colors.cyan,

    );
  }
}

class HeroSceneClass3 extends StatelessWidget{

  @override
  Widget build(BuildContext context){
    return Container(
      child: Text('英雄攻略'),

      alignment: Alignment.centerLeft,
      width: 500,
      height: 620,

      //color: Colors.cyan,

    );
  }
}

class HeroSceneClass4 extends StatelessWidget{

  @override
  Widget build(BuildContext context){
    return Container(
      child: Text('暂未开放'),

      alignment: Alignment.centerLeft,
      width: 500,
      height: 620,

      //color: Colors.cyan,

    );
  }
}


