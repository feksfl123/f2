import 'package:demo04/HeroListClass.dart';
import 'package:flutter/material.dart';
import 'package:flutter_simple_video_player/flutter_simple_video_player.dart';
import 'dart:ui';
import 'main.dart';


class SimpleMupageBoss extends StatefulWidget {
  SimpleMupageBoss({Key key,@required this.spPlayerIdx}) : super(key: key);
  final int spPlayerIdx;
  SimpleMupage createState() => SimpleMupage();
}

class SimpleMupage extends State<SimpleMupageBoss> {
  @override
  List MupageList;//片源
  int MUpageCount=0;//片级
  factory SimpleMupage() =>_getInstance();
  static SimpleMupage _instance;
  static SimpleMupage _getInstance() {
      _instance = new SimpleMupage._internal();
    return _instance;
  }
  void UpdateState(){
   setState(() {

   });


  }
  SimpleMupage._internal() {
    // 初始化
  }
  Widget build(BuildContext context) {
    MupageList=JSListClass.JsList[widget.spPlayerIdx]['movie'];//获取片源

    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(40.0),
          child: AppBar(title: Text('影视详情'),
          backgroundColor: Colors.black,
          )
      ),

        body: Container(
          width: double.infinity,
          height: double.infinity,
          child: ListView(
            physics: NeverScrollableScrollPhysics(),
            children: <Widget>[
              Container(
                height: 230,
                child: SimpleViewPlayer(MupageList[MUpageCount], isFullScreen: false,),
              ),
              FilmtelevDetails(spPlayerIdx:widget.spPlayerIdx,MupagePaList:MupageList),
            ],
          )
        )
    );
  }

  void setUpdateMupage(int MpIdx){
    MUpageCount=MpIdx;
  }
  int getUpdateMupage(){
    return MUpageCount;
  }


}

class FilmtelevDetails extends StatefulWidget {
  FilmtelevDetails({Key key,@required this.spPlayerIdx,@required this.MupagePaList}) : super(key: key);
  final int spPlayerIdx;
  final List MupagePaList;
  _FilmtelevDetails createState() => _FilmtelevDetails();
}

//影视详情类
class _FilmtelevDetails extends State<FilmtelevDetails>{
  Color _DefaultBcolor= Colors.cyan;
  int volumefilm=0;
  @override
  Widget build(BuildContext context){
    if(MainBottomNavigation.instance.maps.length>=1){
      //判断数据库中是否有相同影视
      for(var obj in MainBottomNavigation.instance.maps){
          if(JSListClass.JsList[widget.spPlayerIdx]['name']==obj.values){
            //相同的数据则改数据库中的values

          }
      }

    }

    return Container(
      height: window.physicalSize.height/3.3,
      child: ListView(
        children: <Widget>[
          Column(
            children: <Widget>[
              Card(
                child: Container(
                  width:  double.infinity,
                  height: 165,
                  child: Stack(
                    children: <Widget>[
                      Positioned(
                        top: 10.0,
                        left: 0.0,
                        child: Text(JSListClass.JsList[widget.spPlayerIdx]['name'], style: TextStyle(
                            color: Colors.black, fontSize: 22.0),),
                      ),
                      Positioned(
                        top: 15.0,
                        left: 160.0,
                        child: Text(JSListClass.JsList[widget.spPlayerIdx]['score'], style: TextStyle(
                            color: Colors.deepOrange, fontSize: 18.0),),
                      ),

                      Positioned(
                        top: 60.0,
                        left: 3.0,
                        child: Text('主演：', style: TextStyle(
                            color: Colors.black, fontSize: 18.0),),
                      ),
                      Positioned(
                        top: 60.0,
                        left: 60.0,
                        child: Text(JSListClass.JsList[widget.spPlayerIdx]['Starring'], style: TextStyle(
                            color: Colors.black, fontSize: 18.0),),
                      ),
                      Positioned(
                        top: 100.0,
                        left: 3.0,
                        child: Text('导演：', style: TextStyle(
                            color: Colors.black, fontSize: 18.0),),
                      ),
                      Positioned(
                        top: 100.0,
                        left: 60.0,
                        child: Text(JSListClass.JsList[widget.spPlayerIdx]['director'], style: TextStyle(
                            color: Colors.black, fontSize: 18.0),),
                      ),

                      Positioned(
                        top: 102.0,
                        left: 155.0,
                        child: Text('年代：', style: TextStyle(
                            color: Colors.black, fontSize: 18.0),),
                      ),
                      Positioned(
                        top: 102.0,
                        left: 210.0,
                        child: Text(JSListClass.JsList[widget.spPlayerIdx]['age'], style: TextStyle(
                            color: Colors.black, fontSize: 18.0),),
                      ),

                      Positioned(
                        top: 100.0,
                        left: 280.0,
                        child: Text('类型：', style: TextStyle(
                            color: Colors.black, fontSize: 18.0),),
                      ),

                      Positioned(
                        top: 100.0,
                        left: 335.0,
                        child: Text(JSListClass.JsList[widget.spPlayerIdx]['type'], style: TextStyle(
                            color: Colors.black, fontSize: 18.0),),
                      ),
                      Positioned(
                        top: 135.0,
                        left: 3.0,
                        child: Text('剧情介绍：', style: TextStyle(
                            color: Colors.black, fontSize: 18.0),),
                      ),
                      Positioned(
                        top: 160.0,
                        left: 3.0,
                        child: Container(
                          height: 5,
                          width: 75,
                          color: Colors.black87,
                        )
                      ),
                    ],
                  ),
                ),
              ),
              Card(
                child:     Container(
                  padding: EdgeInsets.all(10.0),
                  alignment: Alignment.topLeft,
                  child:  Text(JSListClass.JsList[widget.spPlayerIdx]['story'], style: TextStyle(
                      color: Colors.black, fontSize: 18.0),),
                )

              ),
               Container(
                    alignment: Alignment.topLeft,
                    child:  Text(' 播放集数：', style: TextStyle(
                        color: Colors.black, fontSize: 18.0),),
               ),

                Align(
                  alignment: FractionalOffset(0.019, 0.0),
                  child: Container(

                    height: 5,
                    width: 71,
                    color: Colors.black87,
                  ),
                ),
                Container(
                  height: 5,
                ),
                Container(
                  width: 400,
                  height: 200,
                  child: GridView.count(
                      crossAxisSpacing: 20,
                      crossAxisCount: 5,
                    children: List.generate(widget.MupagePaList.length,(index){
                      int tmepIdx=index+1;
                      if(index==volumefilm)
                        {
                          _DefaultBcolor= Colors.purple;
                        }
                        else{
                         _DefaultBcolor= Colors.cyan;
                        }
                      return Center(
                        child: Card(
                            color: _DefaultBcolor,
                            child: Container(
                              alignment: Alignment.center,
                              width: 100,
                              height: 30,
                            child: GestureDetector(
                              child: Text('第$tmepIdx集',style: TextStyle(fontSize: 17.0,color: Colors.white),),
                              //选择播放的集数
                              onTap: (){
                                pleViewPlayerState.instance.controller.pause();
                                SimpleMupage._instance.setUpdateMupage(1);
                                SimpleMupage._instance.UpdateState();
                                pleViewPlayerState.instance.yoered(widget.MupagePaList[index]);
                                volumefilm=index;
                                setState(() {

                                });

                              },

                            )
                          )
                        ),
                      );

                    },)




                  ),
                )

            ],
          )

        ],
      ),
    );


  }
}