import 'package:flutter/material.dart';
import 'dart:ui';
import 'HeroListClass.dart';
import 'SimpleMUPage.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
//分类


class PaginationType3 extends StatelessWidget{

  @override

  Widget build(BuildContext context){

    return Scaffold(
      appBar: PreferredSize(
          child: AppBar(
            title: Text('分类'),
            brightness: Brightness.light,
            backgroundColor: Colors.deepPurpleAccent,
          ),
          preferredSize: Size.fromHeight(45)),
        body: Center(
          child: PaginationBase(),
        )
    );

  }
}



class PaginationBase extends StatefulWidget {
  _PaginationBase createState() => _PaginationBase();
}


class _PaginationBase extends State<PaginationBase>{
  @override
  //类型
  List<double> elevation1=[3,0,0,0,0];
  List<double> elevation2=[3,0,0,0,0];
  List<double> elevation3=[3,0,0,0,0];

  List<Color> ButtonColor1=[Color.fromARGB(255, 100, 255, 0),Color.fromARGB(255, 255, 255, 255),
    Color.fromARGB(255, 255, 255, 255),Color.fromARGB(255, 255, 255, 255),Color.fromARGB(255, 255, 255, 255)];

  List<Color> ButtonColor2=[Color.fromARGB(255, 100, 255, 0),Color.fromARGB(255, 255, 255, 255),
    Color.fromARGB(255, 255, 255, 255),Color.fromARGB(255, 255, 255, 255),Color.fromARGB(255, 255, 255, 255)];

  List<Color> ButtonColor3=[Color.fromARGB(255, 100, 255, 0),Color.fromARGB(255, 255, 255, 255),
    Color.fromARGB(255, 255, 255, 255),Color.fromARGB(255, 255, 255, 255),Color.fromARGB(255, 255, 255, 255)];

  List PaginatList=JSListClass.JsList;

  Widget build(BuildContext context){
    initCinemaList();//初始化数据
    return Center(
      child: ListView(
        children: <Widget>[
          Container(
            height: 10.0,
          ),
          Card(
            child: Stack(
              children: <Widget>[
                Container(
                  height: 150,
                ),
                Positioned(
                  left: 5,
                  child: Text('类型：',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                ),
                Positioned(
                  left: 5,
                  top: 35,
                  child: Text('地区：',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                ),
                Positioned(
                  left: 5,
                  top: 70,
                  child: Text('年代：',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                ),
                Positioned(
                  left: 5,
                  top: 108,
                  child: Text('片源：',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                ),



                //添加类型
                Positioned(
                  left: 65,
                    top: -2,
                    child: Card(
                      elevation: elevation1[0],
                      color: ButtonColor1[0],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('全部',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),

                            onTap: (){
                              for (var i=0;i<5;i++)
                               {
                                 elevation1[i]=0;
                                 ButtonColor1[i]=Color.fromARGB(255, 255, 255, 255);
                               }
                              setState(() {
                                elevation1[0]=3;
                                ButtonColor1[0]=Color.fromARGB(255, 100, 255, 0);

                              });

                            })

                    )
                ),

                Positioned(
                  left: 125,
                    top: -2,
                    child: Card(
                      elevation: elevation1[1],
                      color: ButtonColor1[1],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('喜剧',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation1[i]=0;
                                ButtonColor1[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation1[1]=3;
                                ButtonColor1[1]=Color.fromARGB(255, 100, 255, 0);

                              });

                            })
                    )
                ),

                Positioned(
                  left: 185,
                    top: -2,
                    child: Card(
                      elevation: elevation1[2],
                      color: ButtonColor1[2],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('爱情',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation1[i]=0;
                                ButtonColor1[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation1[2]=3;
                                ButtonColor1[2]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),


                Positioned(
                  left: 245,
                    top: -2,
                    child: Card(
                      elevation: elevation1[3],
                      color:ButtonColor1[3],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('动作',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation1[i]=0;
                                ButtonColor1[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation1[3]=3;
                                ButtonColor1[3]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),

                Positioned(
                  left: 305,
                    top: -2,
                    child: Card(
                      elevation: elevation1[4],
                      color: ButtonColor1[4],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('科幻',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation1[i]=0;
                                ButtonColor1[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation1[4]=3;
                                ButtonColor1[4]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),



                //添加地区
                Positioned(
                  left: 65,
                  top: 33,
                    child: Card(
                      elevation: elevation2[0],
                      color: ButtonColor2[0],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('全部',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation2[i]=0;
                                ButtonColor2[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation2[0]=3;
                                ButtonColor2[0]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),



                Positioned(
                  left: 125,
                  top: 33,
                    child: Card(
                      elevation: elevation2[1],
                      color: ButtonColor2[1],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('内地',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation2[i]=0;
                                ButtonColor2[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation2[1]=3;
                                ButtonColor2[1]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),


                Positioned(
                  left: 185,
                  top: 33,
                    child: Card(
                      elevation: elevation2[2],
                      color: ButtonColor2[2],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('美国',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation2[i]=0;
                                ButtonColor2[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation2[2]=3;
                                ButtonColor2[2]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),


                Positioned(
                  left: 245,
                  top: 33,
                    child: Card(
                      elevation: elevation2[3],
                      color: ButtonColor2[3],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('日本',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation2[i]=0;
                                ButtonColor2[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation2[3]=3;
                                ButtonColor2[3]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),



                Positioned(
                  left: 305,
                  top: 33,
                    child: Card(
                      elevation: elevation2[4],
                      color: ButtonColor2[4],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('英国',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation2[i]=0;
                                ButtonColor2[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation2[4]=3;
                                ButtonColor2[4]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),



                //添加年代
                Positioned(
                  left: 65,
                  top: 68,
                    child: Card(
                      elevation: elevation3[0],
                      color: ButtonColor3[0],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('全部',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation3[i]=0;
                                ButtonColor3[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation3[0]=3;
                                ButtonColor3[0]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),


                Positioned(
                  left: 125,
                  top: 68,
                    child: Card(
                      elevation: elevation3[1],
                      color: ButtonColor3[1],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('2019',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation3[i]=0;
                                ButtonColor3[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation3[1]=3;
                                ButtonColor3[1]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),


                Positioned(
                  left: 185,
                  top: 68,
                    child: Card(
                      elevation: elevation3[2],
                      color: ButtonColor3[2],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('2018',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation3[i]=0;
                                ButtonColor3[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation3[2]=3;
                                ButtonColor3[2]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),


                Positioned(
                  left: 245,
                  top: 68,
                    child: Card(
                      elevation: elevation3[3],
                      color: ButtonColor3[3],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('2017',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation3[i]=0;
                                ButtonColor3[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation3[3]=3;
                                ButtonColor3[3]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),


                Positioned(
                  left: 305,
                  top: 68,
                    child: Card(
                      elevation: elevation3[4],
                      color: ButtonColor3[4],
                      borderOnForeground: false,
                        child: GestureDetector(
                            child: Text('2016',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                            onTap: (){
                              for (var i=0;i<5;i++)
                              {
                                elevation3[i]=0;
                                ButtonColor3[i]=Color.fromARGB(255, 255, 255, 255);
                              }
                              setState(() {
                                elevation3[4]=3;
                                ButtonColor3[4]=Color.fromARGB(255, 100, 255, 0);

                              });
                            })
                    )
                ),

                //添加片源
                Positioned(
                  left: 65,
                  top: 105,
                    child: Card(
                      elevation: 3,
                      color: Color.fromARGB(255, 100, 255, 0),
                      borderOnForeground: false,
                      child: Text('全部',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w300),),
                    )
                ),


//                Positioned(
//                    bottom: 0,
//                    child: Container(
//                        height: 2,
//                        width: window.physicalSize.width,
//                        color: Colors.teal
//
//                    )
//                ),

              ],
            ),
          ),

          //显示所有电影
          Container(
            width: MediaQuery.of(context).size.width,
            height: window.physicalSize.height/3.5,
            child: AnimationLimiter(
              child: GridView.count(
                  crossAxisCount: 3,
                  childAspectRatio: 0.65,
                  children: List.generate(PaginatList.length,(index){
                    return AnimationConfiguration.staggeredGrid(position: index, columnCount: 2,duration: const Duration(milliseconds: 375), child:
                    SlideAnimation(
                      verticalOffset: 100.0,
                      child: FadeInAnimation(
                        child:
                    Center(
                      child: Stack(
                        children: <Widget>[
                          SizedBox(
                            height: 200.0,
                          ),
                          GestureDetector(
                            onTap: (){
                              Navigator.push(context, MaterialPageRoute(//切换页面
                                  builder:(context)=>SimpleMupageBoss(spPlayerIdx:index)
                              ));

                            },
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(1),
                              child:  Image.network(
                                PaginatList[index]['imname'],
                                fit: BoxFit.cover,
                                width: MediaQuery.of(context).size.width/3.05,
                                height: 170,
                              ),
                            ),
                          ),

                          Positioned(
                              left: 10.0,
                              bottom: 0.0,
                              child: Text(PaginatList[index]['name'],
                                  style: TextStyle(
                                      fontSize: 18.0))
                          ),
                        ],

                      ),
                    )
                      ),
                    )
                    );

                  },)
              ),
            )
          ),


        ],
      ),
    );
  }

  void initCinemaList(){
    this.PaginatList=JSListClass.JsList;
     List templist=[];
     int count=0;

     for(var i=0;i<5;i++){
      if(elevation1[i]==3){
        count=i;
      }
     }
     //判断类型
    if(count!=0)
      {
        for(var obj in PaginatList){
          if(int.parse(obj['type1'])==count){
            templist.add(obj);
          }
        }
        PaginatList=templist;

      }
    //判断地区
    for(var i=0;i<5;i++){
      if(elevation2[i]==3){
        count=i;
      }
    }
    if(count!=0){
      templist=[];
      for(var obj in PaginatList){
        if(int.parse(obj['type2'])==count){
          templist.add(obj);
        }
      }
      PaginatList=templist;

    }
    //判断年代
    for(var i=0;i<5;i++){
      if(elevation3[i]==3){
        count=i;
      }
    }
    if(count!=0){
      templist=[];
      for(var obj in PaginatList){
        if(int.parse(obj['type3'])==count){
          templist.add(obj);
        }
      }
      PaginatList=templist;

    }


  }
}



























