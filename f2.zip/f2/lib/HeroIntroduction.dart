import 'package:flutter/material.dart';

class HeroIntroduction extends StatelessWidget{

  final List HeroInList;
  final int HeroINcouu;

  HeroIntroduction({Key key,@required this.HeroInList,@required this.HeroINcouu}):super(key:key);

  @override
  Widget build(BuildContext context){
    
    return Scaffold(
      appBar: AppBar(title: Text('英雄介绍'),),
      body: Card(
        child:Row(//f=在水平方向排列孩子
          children: <Widget>[
            HerosStoryClass(StoryList:HeroInList,storycouu:HeroINcouu)
          ],
        ),
      )
    );
  }
}


//英雄故事介绍类
class HerosStoryClass extends StatelessWidget{
  final List StoryList;
  final int storycouu;
  HerosStoryClass({Key key,@required this.StoryList,@required this.storycouu}):super(key:key);
  @override

  Widget build(BuildContext context){
    final width=MediaQuery.of(context).size.width;
    final height=MediaQuery.of(context).size.height;
    return Container(
        width: 400,
        height: 800,
        alignment: Alignment.center,
     // color: Colors.black,
      padding: EdgeInsets.all(10.0),

      //color: Colors.black,
        child: ListView(
          //physics: new NeverScrollableScrollPhysics(),//禁用滚动事件
          children: <Widget>[
            Row(
              children: <Widget>[
                Image.network(StoryList[storycouu]['imname'],
                  fit: BoxFit.cover,
                  width: 200,
                  height: 250,
                ),
                Container(
                  width: 180,
                  height: 250,
                  color: Color.fromARGB(200, 25, 26, 33),
                  padding: EdgeInsets.all(6.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,//调整子控件距离
                    children: <Widget>[
                      Container(padding: EdgeInsets.all(5.0),

                       child:  Text(StoryList[storycouu]['mename'],style: TextStyle(color: Colors.white,fontSize: 20.0,),),
                      ),
                      Container(padding: EdgeInsets.all(5.0),

                        child:  Text(StoryList[storycouu]['name'],style: TextStyle(color: Colors.white,fontSize: 20.0,),),
                      ),
                      Container(padding: EdgeInsets.all(3.0),

                        child: Row(
                          children: <Widget>[
                        Container(
                          child: Image.asset(StoryList[storycouu]['tppos']),
                        ),

                            Container(
                              padding: EdgeInsets.all(11.0),
                              child:  Text(StoryList[storycouu]['type'],style: TextStyle(color: Colors.white,fontSize: 20.0,),),
                            ),


                          ],
                        )
                      ),

                      Container(padding: EdgeInsets.all(3.0),

                          child: Row(
                            children: <Widget>[
                              Container(
                                child:  Text('生存能力：',style: TextStyle(color: Colors.white,fontSize: 18.0,),),
                              ),

                              Container(
                                padding: EdgeInsets.all(5.0),
                                child:  Text(StoryList[storycouu]['scnum'],style: TextStyle(color: Colors.white,fontSize: 18.0,),),
                              ),


                            ],
                          )
                      ),
                      Container(
                          padding: EdgeInsets.all(3.0),
                          child: Row(
                            children: <Widget>[
                              Container(
                                child:  Text('上手难度：',style: TextStyle(color: Colors.white,fontSize: 18.0,),),
                              ),

                              Container(  padding: EdgeInsets.all(5.0),

                                child:  Text(StoryList[storycouu]['ssnum'],style: TextStyle(color: Colors.white,fontSize: 18.0,),),
                              ),


                            ],
                          )
                      ),

                    ],
                  ),
                ),

              ],
            ),
            Container(
              height: 20,
            ),
            //技能介绍
             Container(
                child: Row(
                  children: <Widget>[
                    Icon(Icons.table_chart),
                    Text(' 技能介绍',style: TextStyle(fontSize: 20.0),),

                  ],
                )
              ),
            Container(
              height: 20,
            ),
            Card(
              child: Container(
                  height: 200,
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(5),
                            child:   Image.network('https://game.gtimg.cn/images/yxzj/img201606/heroimg/523/52300.png',
                              width: 70,
                              height: 70,
                            ),
                          ),

                          Container(
                            padding: EdgeInsets.all(5),

                            child:   Image.network('https://game.gtimg.cn/images/yxzj/img201606/heroimg/523/52310.png',
                              width: 70,
                              height: 70,
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.all(5),

                            child:   Image.network('https://game.gtimg.cn/images/yxzj/img201606/heroimg/523/52320.png',
                              width: 70,
                              height: 70,
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.all(5),

                            child:   Image.network('https://game.gtimg.cn/images/yxzj/img201606/heroimg/523/52330.png',
                              width: 70,
                              height: 70,
                            ),
                          ),
                        ],
                      ),
                      //技能文字
                      Row(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.all(5),
                            child:   Text('心无旁骛',style: TextStyle(fontSize: 17.0,fontWeight: FontWeight.bold))
                          ),
                          Container(
                              padding: EdgeInsets.all(15),
                              child:   Text('   冷却值 : 15   消耗: 0',style: TextStyle(fontSize: 17.0,color:Colors.black87))
                          ),

                        ],
                      ),
                      Row(
                        children: <Widget>[
                          Container(
                              padding: EdgeInsets.all(5),
                              child:   Text('技能伤害会随着与敌人间的距离而增加，最多提升40%',style: TextStyle(fontSize: 15.0))
                          ),

                        ],
                      ),
                      Container(
                          width: 300,
                          height: 5,
                      ),
                      Container(
                        width: 350,
                        height: 25,
                        color: Colors.black12,
                        alignment: Alignment.topLeft,
                          padding: EdgeInsets.all(2),
                          child:   Text('  拉开距离可以打出更多伤害',style: TextStyle(fontSize: 15.0))
                      ),

                    ],
                  )
              ),
            ),
            //技能加点建议
            Container(height: 13,),//调整子控件距离
            Container(
                child: Row(
                  children: <Widget>[
                    Icon(Icons.table_chart),
                    Text(' 技能加点建议',style: TextStyle(fontSize: 20.0),),

                  ],
                )
            ),
            Container(height: 10,),//调整子控件距离

            //加点界面
            Card(
              child: Container(
                  height: 100,
                  child: Stack(
                    children: <Widget>[
                      Positioned(
                        left: 10,
                        bottom: 50,
                        child: Text('主升',style: TextStyle(fontSize: 17.0),),
                      ),
                      Positioned(
                        left: 10,
                        bottom: 20,
                        child: Text('纱缚之印',style: TextStyle(fontSize: 17.0),),
                      ),
                      Positioned(
                        left: 90,
                        bottom: 10,
                        child: Image.network('https://game.gtimg.cn/images/yxzj/img201606/heroimg/523/52310.png',
                        width: 70,
                        height: 70,
                        ),
                      ),
                      Positioned(
                        left: 180,
                        bottom: 50,
                        child: Text('副升',style: TextStyle(fontSize: 17.0),),
                      ),
                      Positioned(
                        left: 180,
                        bottom: 20,
                        child: Text('心无旁骛',style: TextStyle(fontSize: 17.0),),
                      ),
                      Positioned(
                        left: 260,
                        bottom: 10,
                        child: Image.network('https://game.gtimg.cn/images/yxzj/img201606/heroimg/523/52330.png',
                          width: 70,
                          height: 70,
                        ),
                      ),
                    ],
                  )
              ),
            ),
          ],
        ),
    );
  }
}
