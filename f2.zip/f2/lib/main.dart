import 'package:flutter/material.dart';
import 'keepAliveDemo.dart';
import 'heroListInfo.dart';
import 'HeroListClass.dart';
import 'videoPlayClass.dart';
import 'SimpleMUPage.dart';

//新
import 'PaginationType1.dart';
import 'PaginationType2.dart';
import 'PaginationType3.dart';
import 'PaginationType4.dart';
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';
import 'SplashScreen.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

void main(){
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget{

  @override
  //历史数据
  String PersinStr;
  Future<SharedPreferences> _prefs=SharedPreferences.getInstance();
  static bool ascendproces;
  static String paginationname;
  Widget build(BuildContext context){
    decodePerson();
    initFromCache();



    return MaterialApp(
      title: 'flutter demo4',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: BottomNavigation(),//SimpleMupage(),

    );
  }
  @override
  //从缓存中获取信息填充
  void initFromCache() async {
    final SharedPreferences prefs = await _prefs;
    final nickname = prefs.getString("paginationname");//历史信息
    bool AscendProcess=prefs.getBool("ascendproces");//历史信息
    if (AscendProcess == null) {
      prefs.setBool("ascendproces", false);
      AscendProcess=false;
    }
    ascendproces=AscendProcess;
    if (nickname == null) {
      prefs.setString("paginationname", "0");
      paginationname="0";

    }
    paginationname=nickname;
  }

  //保存界面信息
  void saveString(String str1,String str2) async {
    final SharedPreferences prefs = await _prefs;
    prefs.setString(str1, str2);
  }
  //保存界面信息
  void saveBool(String str1,bool bt) async {
    final SharedPreferences prefs = await _prefs;
    prefs.setBool(str1, bt);
  }
}


class BottomNavigation extends StatefulWidget{

  MainBottomNavigation createState()=> MainBottomNavigation();
}

class MainBottomNavigation extends State<BottomNavigation> {
  Color _bottomColor1=Colors.lightBlue;
  Color _bottomColor2=Colors.grey;
  Color _bottomColor3=Colors.grey;
  Color _bottomColor4=Colors.grey;
  int _currenType=0;
  int _controlJson=0;
  Database db;
  List<Map> maps=[];

  List<Widget> list =List();
  factory MainBottomNavigation() =>_getInstance();
  static MainBottomNavigation instance;
  static MainBottomNavigation _getInstance() {
    instance = new MainBottomNavigation._internal();
    return instance;
  }
  void UpdateState(){
    setState(() {
      _currenType=2;
      _bottomColor1=Colors.grey;
      _bottomColor2=Colors.grey;
      _bottomColor3=Colors.lightBlue;
      _bottomColor4=Colors.grey;
    });

  }
  MainBottomNavigation._internal() {
    // 初始化
  }


  @override

  void initState() {
    list
      ..add(ImagesAnim([],100,100,Colors.pink))
      ..add(PaginationType2())
      ..add(PaginationType3())
      ..add(PaginationType4());
    super.initState();
  }


  @override
  Widget build(BuildContext context){
    //等待数据
    if(JSListClass.JsList.length<=0)
      {
        Timer _timer=new Timer(new Duration(milliseconds: 1500), (){
          setState(() {
            list[_currenType]=PaginationType1();
          });
        });
        _controlJson=99;
      }
      else if(_controlJson==0){
      _controlJson=99;
      list[_currenType]=PaginationType1();
    }


    return Scaffold(
        body: list[_currenType],
        bottomNavigationBar: BottomNavigationBar(
          items: [

            BottomNavigationBarItem(
              icon: Icon(
                Icons.home,
                color: _bottomColor1,
              ),
              title: Text(
                '首页',
                style: TextStyle(color: _bottomColor1),
              )
            ),
            BottomNavigationBarItem(
                icon: Icon(
                  Icons.search,
                  color: _bottomColor2,
                ),
                title: Text(
                  '发现',
                  style: TextStyle(color: _bottomColor2),
                )
            ),
            BottomNavigationBarItem(
                icon: Icon(
                  Icons.dashboard,
                  color: _bottomColor3,
                ),
                title: Text(
                  '分类',
                  style: TextStyle(color: _bottomColor3),
                )
            ),
            BottomNavigationBarItem(
                icon: Icon(
                  Icons.person,
                  color: _bottomColor4,
                ),
                title: Text(
                  '个人',
                  style: TextStyle(color: _bottomColor4),
                )
            ),
          ],
          currentIndex: _currenType,
          onTap: (int index){
            if(index==0)
            {
              _bottomColor1=Colors.lightBlue;
              _bottomColor2=Colors.grey;
              _bottomColor3=Colors.grey;
              _bottomColor4=Colors.grey;
            }else if(index==1){
              _bottomColor1=Colors.grey;
              _bottomColor2=Colors.lightBlue;
              _bottomColor3=Colors.grey;
              _bottomColor4=Colors.grey;
            }if(index==2){
              _bottomColor1=Colors.grey;
              _bottomColor2=Colors.grey;
              _bottomColor3=Colors.lightBlue;
              _bottomColor4=Colors.grey;
            }if(index==3){
              _bottomColor1=Colors.grey;
              _bottomColor2=Colors.grey;
              _bottomColor3=Colors.grey;
              _bottomColor4=Colors.lightBlue;
            }
            setState(() {
              _currenType=index;
            });
          },
          type: BottomNavigationBarType.fixed,
        ),
    );
  }
}




