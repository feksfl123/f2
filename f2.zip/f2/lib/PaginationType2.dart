import 'package:flutter/material.dart';
import 'Browser.dart';
//发现
class PaginationType2 extends StatelessWidget{

  @override

  Widget build(BuildContext context){

    return Scaffold(
        body: Center(
          child: Browser(url:'http://www.gaoxiao8.org/category/gao-xiao-wen-zhang',title: "发现"),
        )
    );

  }
}